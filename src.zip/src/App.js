import { Routes, Route } from 'react-router-dom';
import './App.css'
import HomePage from './routes/HomePage';
import Login from './routes/Login';
import SignUp from './routes/SignUp';



function App() {
  return (
      <div>
       <Routes>
          <Route path='/' element= {<HomePage />} />
          <Route path='/login' element= {<Login />} />
          <Route path='/signup' element= {<SignUp />} />
        </Routes>
      </div>

  
  );

}

export default App;
