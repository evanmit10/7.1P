import React from "react";
import {NavLink} from "react-router-dom";
import '../button.css';
import '../navButton.css';
import '../navButton2.css';
import '../search.css';

const HomePage =(props) => {
    return (
      <div>
        <div className="topnav">
          <p style={{position: "absolute", left: "0px", fontWeight:"bold", fontSize:"25px", top:"-17px"}}>DEV@Deakin 2022</p>
        <ul className="buttoncreation">
          <NavLink style={{positon: "relative", top: "0px", height:"24px", left: "1482px"}} type="submit" className="button" to='/login'>Login</NavLink>
        </ul>
        <ul className="buttoncreation">
          <NavLink style={{positon: "relative", top: "0px", height:"24px", left: "1382px"}} type="submit" className="button" to='/post'>Post</NavLink>
        </ul>
          <form action="/action_page.php">
          <input style={{width: "1110px", position: "relative", top:"-12px", left: "250px"}}type="text" placeholder="Search.." name="search" />
        </form>
        </div>
      </div>
    );
}
export default HomePage;
